package de.xrepo;

public class Gericht {

	private String code;
	private String wert;

	public void setCode(String string) {
		this.code = string;
	}

	public void setWert(String wert) {
		this.wert = wert;
	}

}
