package de.xrepo;

public class MyXML {

	// private List<String> list;
	//
	// public MyXML(List<String> list) {
	// XDocument xdoc = XDocument.Parse(e.Result, LoadOptions.None);
	// }

}
